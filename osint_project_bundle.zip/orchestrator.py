import time
from skills.scout_skill import scout_node
from skills.critic_skill import critic_node
from skills.reporter_skill import reporter_node

def run_agent_workflow(sector, threat, context, max_retries=2):
    state = {
        "sector": sector,
        "threat": threat,
        "context": context,
        "messages": [],
        "findings": "",
        "is_verified": False,
        "retry_count": 0
    }

    while not state["is_verified"] and state["retry_count"] <= max_retries:
        if state["retry_count"] > 0:
            time.sleep(2)
        state = scout_node(state)
        state = critic_node(state)

    if state["is_verified"]:
        state = reporter_node(state)
    else:
        state["report"] = "Failed to verify threat indicators across multiple sources after maximum retries."

    return state
